
var Uname;
var email;
var phone;

var qualifiactions=[];


function get(x) {
    return document.getElementById(x);
}

function addSubjects() {
    get('qualification-list').innerHTML="";
    var degreeDetails = {
        Dname: get('name').value,
        specialization:get("number").value,
        startyear:get("email").value,
    };
    Uname = document.getElementById('name').value;
    qualifiactions.push(degreeDetails);

    for(var i=0;i<qualifiactions.length;i++){
        var s = document.createElement('p');
        s.setAttribute('id',qualifiactions[i].Dname);
        s.innerHTML="Name: "+qualifiactions[i].Dname +"<br> Mobile No:"+qualifiactions[i].specialization +" <br>Email Id: "+qualifiactions[i].startyear +"<br> <button id='delete-qualifiaction' onclick='deletequalification("+qualifiactions[i].Dname+")'>delete</button> <br>";
        get('qualification-list').appendChild(s);
    }

    get('degree').value='';
    get('specilisation').value='';
    get('start').value='';
    get('end').value='';
};

function deletequalification(name) {

    for(var i=0;i<qualifiactions.length;i++){
        if(name.id == qualifiactions[i].Dname){
            qualifiactions.splice(i,1);
        }
    }
    get('qualification-list').innerHTML="";
    for( i=0;i<qualifiactions.length;i++){
        var s = document.createElement('p');
        s.setAttribute('id',qualifiactions[i].Dname);
        s.innerHTML=qualifiactions[i].Dname +" in "+qualifiactions[i].specialization +" from "+qualifiactions[i].startyear +" to "+qualifiactions[i].endyear+" <button id='delete-qualifiaction' onclick='deletequalification("+qualifiactions[i].Dname+")'>delete</button> <br>";
        get('qualification-list').appendChild(s);
    }
    
}

document.getElementById('submit').addEventListener('click',function(event){
    event.preventDefault();
})